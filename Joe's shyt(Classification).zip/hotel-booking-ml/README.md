# Hotel Booking Demand (City Hotel, H2) - ML Project

End-to-end ML workflow on the H2 City Hotel booking data (regression, classification, clustering).
This repo currently contains the **classification** component (target: `IsCanceled`);
regression and clustering live in sibling packages (`hotel_ml/regression`, `hotel_ml/clustering`).

## Team
| Member | GitHub | Responsibility |
|---|---|---|
| Youssef | `<github-username>` | Classification |
| `<name>` | `<github-username>` | Regression |
| `<name>` | `<github-username>` | Clustering |

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```
Place `train.csv`, `val.csv`, `test.csv` in `data/splits/`.

## Run (from repo root)
```bash
python -m hotel_ml.classification.eda              # EDA tables + figures  -> reports/classification/
python -m hotel_ml.classification.train_baseline   # untuned baselines (train -> val, grouped CV) -> artifacts/ + reports/
python -m hotel_ml.classification.leakage_audit    # single-feature + feature-set ablation audit
python -m hotel_ml.classification.predict --input data/splits/val.csv --output preds.csv   # inference from saved artifact
python scripts/check_against_transformed.py train_transformed.csv val_transformed.csv      # preprocessing consistency check
```

## Structure
```
hotel_ml/
  config.py            paths, seed (42), column groups, feature sets
  data.py              split loading (test only loaded on explicit request)
  preprocessing.py     reusable sklearn preprocessing pipeline (fit on train only)
  classification/      eda, models, train_baseline, evaluate, leakage_audit, predict
data/splits/           train.csv, val.csv, test.csv (pre-split by GroupId)
artifacts/             saved fitted pipelines (.joblib): preprocessing + model in ONE object
reports/classification/  metrics CSV/JSON, EDA summary, figures, written reports
scripts/               helper/check scripts
```

## Reproducibility rules
- Fixed seed `SEED = 42` (`hotel_ml/config.py`).
- Train/val/test were split **by `GroupId`** (identical bookings share a group), so no duplicate leaks across splits;
  cross-validation inside train uses `StratifiedGroupKFold` on `GroupId`. `GroupId` is never a feature.
- All data-dependent preprocessing (median/scaler statistics, one-hot categories) is fitted on train only.
- The **test split is untouched** until final evaluation.
- Inference loads `artifacts/classification/*.joblib`; nothing is retrained at startup.
- `random_forest.joblib` (42 MB) is git-ignored; recreate it with `train_baseline`.
