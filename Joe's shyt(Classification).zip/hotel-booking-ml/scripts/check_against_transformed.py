"""Sanity check: does our reusable preprocessing reproduce the team's *_transformed.csv files?

Run (from repo root):
  python scripts/check_against_transformed.py path/to/train_transformed.csv path/to/val_transformed.csv
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hotel_ml.config import TARGET  # noqa: E402
from hotel_ml.data import load_split, split_xy  # noqa: E402
from hotel_ml.preprocessing import build_pipeline  # noqa: E402

train_t, val_t = sys.argv[1], sys.argv[2]
X_tr, y_tr, _ = split_xy(load_split("train"))
X_va, y_va, _ = split_xy(load_split("val"))

pipe = build_pipeline(model="passthrough")
pipe.fit(X_tr, y_tr)
cols = pipe.named_steps["cols"]
prep = pipe.named_steps["prepare"]
names = list(cols.get_feature_names_out())

for label, X, ref_path in [("train", X_tr, train_t), ("val", X_va, val_t)]:
    mine = pd.DataFrame(cols.transform(prep.transform(X)), columns=names)
    ref = pd.read_csv(ref_path).drop(columns=[TARGET])
    same_cols = list(ref.columns) == names
    diff = np.abs(mine.values - ref.values).max() if mine.shape == ref.shape else float("nan")
    print(f"{label}: shape mine={mine.shape} ref={ref.shape} | same column order={same_cols} | max abs diff={diff:.2e}")
