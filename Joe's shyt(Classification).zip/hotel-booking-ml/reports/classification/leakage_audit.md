# Preliminary leakage audit - classification (target: `IsCanceled`)

**Prediction point:** the moment a booking is created/confirmed, before arrival. The model should only use
information known then. Predicting whether a booking will be canceled.

## Already removed upstream (not present in the supplied splits)
Fields that reveal or follow the outcome: `ReservationStatus`, `ReservationStatusDate`, `AssignedRoomType`,
`BookingChanges`, `RequiredCarParkingSpaces`. Confirm with the team that these stay excluded for all tasks.

## Handled by design
- **Duplicate bookings across splits:** splits are grouped by `GroupId` (0 groups shared between train/val/test).
  ~35% of train rows are exact duplicates of another row; CV uses `StratifiedGroupKFold` so duplicates never
  straddle folds.
- **`GroupId`** is an identifier, never used as a feature.
- **Preprocessing leakage:** imputers, scalers and encoders are fitted inside the pipeline on train only.
- **Test set** not loaded by any Milestone 1 script.

## Features flagged for review
| Feature | Evidence | Concern | Decision for M1 |
|---|---|---|---|
| `DepositType` | `Non Refund` bookings are 99.8% canceled (7,966 train rows); best single feature (val AUC 0.693) | Known to be a data/policy artifact of this hotel rather than guest behavior; is known at booking time, so not temporal leakage, but a shortcut | Kept; reported with and without |
| `ADR` | `ADR = 0` rows cancel 10% vs 42% overall | Price can be revised after booking/cancellation; 0 marks complimentary stays | Kept; flagged |
| `TotalOfSpecialRequests` | 3rd strongest single feature (AUC 0.679) | Requests can be added after booking is created | Kept; flagged |
| `DaysInWaitingList` | rare (4.8% > 0) | Accumulates over time before confirmation | Kept; flagged |

## Ablation (validation set, untuned)
| Feature set | Dropped | LogReg AUC | HistGB AUC | HistGB F1 |
|---|---|---|---|---|
| all | - | 0.859 | 0.886 | 0.777 |
| no_deposit | DepositType | 0.847 | 0.881 | 0.752 |
| strict_booking_time | DepositType, ADR, TotalOfSpecialRequests, DaysInWaitingList | 0.809 | 0.835 | 0.669 |

Interpretation: performance is robust to dropping `DepositType` (AUC -0.005 for HistGB) but drops noticeably when all
four suspect fields are removed (AUC -0.05). The final model must decide, with the team, which fields are truly
available at the chosen prediction point. Full numbers: `leakage_ablation_val.csv`, `leakage_single_feature_auc.csv`.
