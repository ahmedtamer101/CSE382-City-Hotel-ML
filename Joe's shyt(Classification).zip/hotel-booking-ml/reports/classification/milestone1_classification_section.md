# Milestone 1 - Classification section (draft for the progress report)

## Task and prediction point
Binary classification of `IsCanceled` for City Hotel (H2) bookings, predicted at booking time (see leakage audit).

## Data and split strategy
Pre-split by `GroupId`: train 47,719 / val 15,814 / test 15,629 rows (cancellation rate 0.420 / 0.427 / 0.401).
Zero groups overlap across splits. Within train, 5-fold `StratifiedGroupKFold` (seed 42) is used for CV. Test is untouched.

## Preprocessing (reusable sklearn pipeline, fit on train only)
- Missing: `Children` median (4 rows); `MarketSegment`/`DistributionChannel` explicit "Missing" level (2/4 rows);
  `Agent` missing (10.2%) -> category "None".
- Numeric: standardised; right-skewed counts (`LeadTime`, `DaysInWaitingList`, `PreviousCancellations`,
  `PreviousBookingsNotCanceled`, stay-night columns) `log1p` then standardised; binary flags passed through.
- Categorical: one-hot, categories rarer than 0.5% of train pooled into an "infrequent" column.
- Output: 82 features; verified to reproduce the team's `train_transformed.csv` / `val_transformed.csv` (max abs diff 1e-14).

## Baseline results (untuned, default-ish hyperparameters, seed 42)
| Model | Val Acc | Val Prec | Val Rec | Val F1 | Val ROC-AUC | CV Acc (mean±sd) | CV ROC-AUC |
|---|---|---|---|---|---|---|---|
| Majority-class dummy | 0.573 | 0.000 | 0.000 | 0.000 | 0.500 | - | - |
| Logistic Regression | 0.810 | 0.854 | 0.670 | 0.751 | 0.859 | 0.815±0.002 | 0.867 |
| Random Forest (200 trees) | 0.823 | 0.857 | 0.704 | 0.773 | 0.881 | 0.821±0.007 | 0.882 |
| HistGradientBoosting | 0.827 | 0.866 | 0.705 | 0.777 | 0.886 | 0.831±0.004 | 0.894 |

All three models beat the 57.3% majority baseline by 24-25 points. Precision exceeds recall for every model
(threshold 0.5): about 30% of actual cancellations are missed. Gradient boosting is best; the gap between
models is small relative to CV standard deviation for LogReg vs RF. Tuning the decision threshold or using
class weights may raise recall (relevant if missing a cancellation is costlier than a false alarm).

## Observations from EDA
Cancellation is highest for Groups market segment, TA/TO channel, Non Refund deposits, and longer lead times;
lowest for Complementary/Corporate/Direct bookings and bookings with special requests.
~10% of bookings have no agent; 35% of rows are exact duplicates (handled via groups).

## Plan for remaining milestones
Hyperparameter tuning (Optuna: RF, HistGB/XGBoost, LogReg regularisation), threshold selection, PCA/LDA experiments,
final test-set evaluation (once), saved artifacts, and integration into the team CLI/GUI app.

## Member contribution
Youssef: classification EDA, preprocessing pipeline, baselines, leakage audit, inference module.
