# EDA summary (classification, target = IsCanceled)

## Split sizes and target balance
- train: 47,719 rows, cancellation rate 0.420, 31,867 groups, 16,944 duplicate rows
- val: 15,814 rows, cancellation rate 0.427, 10,621 groups, 5,353 duplicate rows
- test: 15,629 rows, cancellation rate 0.401, 10,622 groups, 5,136 duplicate rows
- GroupId overlap across splits: 0  (0 = no duplicate-booking leakage between splits)

## Missing values (train)
- Children: 4 (0.01%)
- MarketSegment: 2 (0.00%)
- DistributionChannel: 4 (0.01%)
- Agent: 4,853 (10.17%)

## Data types (train)
int64      18
float64     7
str         7

## Unusual values (train)
- ADR == 0: 626 rows (1.31%), cancel rate 0.101
- TotalNights == 0: 147 rows
- Babies >= 5: 2 rows; max Babies = 10
- LeadTime max = 629; 99th pct = 454
- DaysInWaitingList > 0: 4.81%
- DepositType value counts: {'No Deposit': 39747, 'Non Refund': 7966, 'Refundable': 6}

## Cancellation rate by categorical feature (train)

**Meal**
```
       mean   size
Meal              
BB    0.431  37612
SC    0.376   6332
HB    0.378   3732
FB    0.814     43
```

**MarketSegment**
```
                mean   size
MarketSegment              
Online TA      0.375  23263
Offline TA/TO  0.442  10176
Groups         0.693   8517
Direct         0.169   3638
Corporate      0.150   1676
Complementary  0.104    318
Aviation       0.225    129
```

**DistributionChannel**
```
                      mean   size
DistributionChannel              
TA/TO                0.454  41548
Direct               0.186   4096
Corporate            0.196   1959
GDS                  0.232    112
```

**ReservedRoomType**
```
                   mean   size
ReservedRoomType              
A                 0.440  37794
D                 0.347   6979
F                 0.379   1080
E                 0.317    912
B                 0.350    666
G                 0.251    279
C                 0.222      9
```

**DepositType**
```
              mean   size
DepositType              
No Deposit   0.304  39747
Non Refund   0.998   7966
Refundable   0.333      6
```

**CustomerType**
```
                  mean   size
CustomerType                 
Transient        0.460  35919
Transient-Party  0.272  10211
Contract         0.515   1400
Group            0.095    189
```

**ArrivalDayOfWeek**
```
                   mean  size
ArrivalDayOfWeek             
Friday            0.437  8456
Thursday          0.487  7734
Monday            0.390  7056
Wednesday         0.419  6857
Saturday          0.430  6370
Sunday            0.351  5678
Tuesday           0.402  5568
```

## Correlation with IsCanceled (train, Pearson)
```
TotalOfSpecialRequests        -0.294
HasCompany                    -0.110
IsRepeatedGuest               -0.066
PreviousBookingsNotCanceled   -0.053
HasKids                       -0.043
WeekendNightRatio             -0.038
ArrivalMonthCos               -0.032
Children                      -0.031
Babies                        -0.029
ADR                           -0.007
ArrivalDateWeekNumber         -0.004
StaysInWeekendNights          -0.002
TotalGuests                    0.009
ArrivalDateDayOfMonth          0.014
Agent                          0.023
ArrivalMonthSin                0.027
Adults                         0.039
TotalNights                    0.042
StaysInWeekNights              0.055
DaysInWaitingList              0.060
HasAgent                       0.069
PreviousCancellations          0.161
LeadTime                       0.314
```