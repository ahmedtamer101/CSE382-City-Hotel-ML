"""Central configuration: paths, seed, and column groups shared by all tasks."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "splits"
ARTIFACT_DIR = ROOT / "artifacts" / "classification"
REPORT_DIR = ROOT / "reports" / "classification"
FIG_DIR = REPORT_DIR / "figures"

SEED = 42

TARGET = "IsCanceled"
GROUP_COL = "GroupId"  # identifies identical/duplicate bookings; used ONLY for grouped CV, never as a feature

# Column groups (match the preprocessing already used for train/val/test)
NUM_COLS = [
    "ArrivalDateWeekNumber", "ArrivalDateDayOfMonth", "Adults", "Children", "Babies",
    "TotalGuests", "TotalOfSpecialRequests", "WeekendNightRatio",
    "ArrivalMonthSin", "ArrivalMonthCos", "ADR",
]
SKEW_COLS = [  # right-skewed counts -> log1p then standardise
    "LeadTime", "DaysInWaitingList", "PreviousCancellations", "PreviousBookingsNotCanceled",
    "StaysInWeekendNights", "StaysInWeekNights", "TotalNights",
]
BIN_COLS = ["IsRepeatedGuest", "HasKids", "HasAgent", "HasCompany"]
CAT_COLS = [
    "Meal", "MarketSegment", "DistributionChannel", "ReservedRoomType",
    "DepositType", "CustomerType", "Agent", "ArrivalDayOfWeek",
]
ALL_FEATURES = NUM_COLS + SKEW_COLS + BIN_COLS + CAT_COLS

# Feature sets used in the leakage / robustness audit
FEATURE_SETS = {
    "all": [],
    # DepositType='Non Refund' is ~99.8% cancelled in this data -> a shortcut, not a booking-behaviour signal
    "no_deposit": ["DepositType"],
    # Also drop fields that can be revised AFTER the booking is created
    "strict_booking_time": ["DepositType", "ADR", "TotalOfSpecialRequests", "DaysInWaitingList"],
}
