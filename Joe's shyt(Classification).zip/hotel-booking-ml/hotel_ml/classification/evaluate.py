"""Metrics and plots for the cancellation classifier."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    ConfusionMatrixDisplay, accuracy_score, average_precision_score, f1_score,
    precision_score, recall_score, roc_auc_score, roc_curve,
)


def compute_metrics(y_true, y_pred, y_proba) -> dict:
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_proba),
        "pr_auc": average_precision_score(y_true, y_proba),
    }


def plot_confusion_matrices(results: dict, y_true, path):
    names = [n for n in results if n != "dummy_majority"]
    fig, axes = plt.subplots(1, len(names), figsize=(4.2 * len(names), 4))
    axes = np.atleast_1d(axes)
    for ax, name in zip(axes, names):
        ConfusionMatrixDisplay.from_predictions(
            y_true, results[name]["y_pred"], ax=ax, cmap="Blues", colorbar=False,
            display_labels=["Not canceled", "Canceled"])
        ax.set_title(name)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_roc_curves(results: dict, y_true, path):
    fig, ax = plt.subplots(figsize=(5.5, 5))
    for name, r in results.items():
        if name == "dummy_majority":
            continue
        fpr, tpr, _ = roc_curve(y_true, r["y_proba"])
        ax.plot(fpr, tpr, label=f"{name} (AUC={r['metrics']['roc_auc']:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("Validation ROC curves (untuned baselines)")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
