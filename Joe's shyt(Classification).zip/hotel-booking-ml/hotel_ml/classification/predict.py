"""Inference: load a saved pipeline artifact and predict cancellation for new bookings.
Nothing is retrained or re-fitted here.

Run:  python -m hotel_ml.classification.predict --input data/splits/val.csv --output preds.csv
"""
import argparse

import joblib
import pandas as pd

from hotel_ml.config import ARTIFACT_DIR


def load_model(name: str = "hist_gradient_boosting"):
    path = ARTIFACT_DIR / f"{name}.joblib"
    if not path.exists():
        raise FileNotFoundError(f"{path} missing - run: python -m hotel_ml.classification.train_baseline")
    return joblib.load(path)


def predict_frame(df: pd.DataFrame, model_name: str = "hist_gradient_boosting") -> pd.DataFrame:
    pipe = load_model(model_name)
    out = pd.DataFrame(index=df.index)
    out["cancel_probability"] = pipe.predict_proba(df)[:, 1]
    out["predicted_canceled"] = (out["cancel_probability"] >= 0.5).astype(int)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="CSV with the booking feature columns")
    ap.add_argument("--output", default=None)
    ap.add_argument("--model", default="hist_gradient_boosting")
    args = ap.parse_args()
    preds = predict_frame(pd.read_csv(args.input), args.model)
    if args.output:
        preds.to_csv(args.output, index=False)
        print(f"wrote {len(preds)} predictions to {args.output}")
    else:
        print(preds.head(10).to_string())


if __name__ == "__main__":
    main()
