"""Milestone 1: untuned baseline classifiers.

Fits on TRAIN, reports on VALIDATION (+ grouped 5-fold CV on train).
The TEST split is never loaded here.

Run:  python -m hotel_ml.classification.train_baseline
"""
import argparse
import json
import time

import joblib
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import StratifiedGroupKFold, cross_validate

from hotel_ml.classification.evaluate import compute_metrics, plot_confusion_matrices, plot_roc_curves
from hotel_ml.classification.models import get_baseline_models
from hotel_ml.config import ARTIFACT_DIR, FEATURE_SETS, FIG_DIR, REPORT_DIR, SEED
from hotel_ml.data import load_split, split_xy
from hotel_ml.preprocessing import build_pipeline


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature-set", default="all", choices=FEATURE_SETS)
    ap.add_argument("--cv-folds", type=int, default=5, help="0 disables cross-validation")
    ap.add_argument("--no-save", action="store_true", help="do not write artifacts/reports")
    args = ap.parse_args()
    drop = FEATURE_SETS[args.feature_set]

    X_tr, y_tr, g_tr = split_xy(load_split("train"))
    X_va, y_va, _ = split_xy(load_split("val"))
    print(f"train {X_tr.shape}, val {X_va.shape}, feature set '{args.feature_set}' (dropped: {drop})")

    results, cv_rows = {}, []
    for name, model in get_baseline_models().items():
        pipe = build_pipeline(model, drop)
        t0 = time.time()
        pipe.fit(X_tr, y_tr)  # all preprocessing statistics learned on train only
        fit_s = time.time() - t0
        y_pred = pipe.predict(X_va)
        y_proba = pipe.predict_proba(X_va)[:, 1]
        m = compute_metrics(y_va, y_pred, y_proba)
        results[name] = {"metrics": m, "y_pred": y_pred, "y_proba": y_proba, "fit_seconds": fit_s}
        print(f"{name:24s} " + "  ".join(f"{k}={v:.4f}" for k, v in m.items()) + f"  ({fit_s:.1f}s)")

        if args.cv_folds and name != "dummy_majority":
            cv = StratifiedGroupKFold(n_splits=args.cv_folds, shuffle=True, random_state=SEED)
            scores = cross_validate(clone(pipe), X_tr, y_tr, groups=g_tr, cv=cv,
                                    scoring=["accuracy", "f1", "roc_auc"])
            row = {"model": name}
            for k in ("accuracy", "f1", "roc_auc"):
                row[f"cv_{k}_mean"] = scores[f"test_{k}"].mean()
                row[f"cv_{k}_std"] = scores[f"test_{k}"].std()
            cv_rows.append(row)
            print(f"   grouped CV: acc={row['cv_accuracy_mean']:.4f}±{row['cv_accuracy_std']:.4f}  "
                  f"f1={row['cv_f1_mean']:.4f}  auc={row['cv_roc_auc_mean']:.4f}")

        if not args.no_save and args.feature_set == "all":
            ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
            joblib.dump(pipe, ARTIFACT_DIR / f"{name}.joblib", compress=3)

    if not args.no_save:
        REPORT_DIR.mkdir(parents=True, exist_ok=True)
        FIG_DIR.mkdir(parents=True, exist_ok=True)
        tag = args.feature_set
        table = pd.DataFrame({n: r["metrics"] for n, r in results.items()}).T
        table.to_csv(REPORT_DIR / f"baseline_val_metrics_{tag}.csv")
        if cv_rows:
            pd.DataFrame(cv_rows).to_csv(REPORT_DIR / f"baseline_cv_metrics_{tag}.csv", index=False)
        with open(REPORT_DIR / f"baseline_val_metrics_{tag}.json", "w") as f:
            json.dump({n: {**r["metrics"], "fit_seconds": r["fit_seconds"]} for n, r in results.items()},
                      f, indent=2)
        if tag == "all":
            plot_confusion_matrices(results, y_va, FIG_DIR / "baseline_confusion_matrices.png")
            plot_roc_curves(results, y_va, FIG_DIR / "baseline_roc_curves.png")
        print(f"saved metrics/figures to {REPORT_DIR}")


if __name__ == "__main__":
    main()
