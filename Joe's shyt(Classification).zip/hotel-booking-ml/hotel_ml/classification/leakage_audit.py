"""Preliminary leakage / shortcut audit (Milestone 1).

1. Single-feature check: how well does each feature alone predict cancellation (val ROC-AUC)?
   Suspiciously strong single features are flagged for manual review against the prediction point.
2. Feature-set ablation: re-run two baselines after removing suspect features.

Fits on TRAIN, scores on VALIDATION. Test split is never touched.
Run:  python -m hotel_ml.classification.leakage_audit
"""
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

from hotel_ml.classification.evaluate import compute_metrics
from hotel_ml.config import ALL_FEATURES, FEATURE_SETS, REPORT_DIR, SEED
from hotel_ml.data import load_split, split_xy
from hotel_ml.preprocessing import build_pipeline


def main():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    X_tr, y_tr, _ = split_xy(load_split("train"))
    X_va, y_va, _ = split_xy(load_split("val"))

    rows = []
    for f in ALL_FEATURES:
        others = [c for c in ALL_FEATURES if c != f]
        pipe = build_pipeline(HistGradientBoostingClassifier(max_iter=60, random_state=SEED), others)
        pipe.fit(X_tr, y_tr)
        rows.append({"feature": f, "val_roc_auc_alone": roc_auc_score(y_va, pipe.predict_proba(X_va)[:, 1])})
    single = pd.DataFrame(rows).sort_values("val_roc_auc_alone", ascending=False)
    single.to_csv(REPORT_DIR / "leakage_single_feature_auc.csv", index=False)
    print(single.round(3).to_string(index=False))

    models = {
        "logistic_regression": lambda: LogisticRegression(max_iter=1000, random_state=SEED),
        "hist_gradient_boosting": lambda: HistGradientBoostingClassifier(random_state=SEED),
    }
    out = []
    for fs, drop in FEATURE_SETS.items():
        for mname, mk in models.items():
            pipe = build_pipeline(mk(), drop)
            pipe.fit(X_tr, y_tr)
            m = compute_metrics(y_va, pipe.predict(X_va), pipe.predict_proba(X_va)[:, 1])
            out.append({"feature_set": fs, "dropped": ", ".join(drop) or "-", "model": mname, **m})
    abl = pd.DataFrame(out)
    abl.to_csv(REPORT_DIR / "leakage_ablation_val.csv", index=False)
    print("\n", abl.round(4).to_string(index=False))


if __name__ == "__main__":
    main()
