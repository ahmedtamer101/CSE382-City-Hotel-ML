"""Milestone 1 EDA for the classification task (target: IsCanceled).

Uses TRAIN for all statistics/plots (val/test only for size + target-rate sanity checks).
Run:  python -m hotel_ml.classification.eda
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from hotel_ml.config import CAT_COLS, FIG_DIR, GROUP_COL, REPORT_DIR, TARGET  # noqa: E402
from hotel_ml.data import load_split  # noqa: E402


def main():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    tr, va, te = (load_split(s) for s in ("train", "val", "test"))
    lines = ["# EDA summary (classification, target = IsCanceled)\n"]

    lines.append("## Split sizes and target balance")
    for n, d in (("train", tr), ("val", va), ("test", te)):
        lines.append(f"- {n}: {len(d):,} rows, cancellation rate {d[TARGET].mean():.3f}, "
                     f"{d[GROUP_COL].nunique():,} groups, {d.drop(columns=[GROUP_COL]).duplicated().sum():,} duplicate rows")
    overlap = len(set(tr[GROUP_COL]) & set(va[GROUP_COL])) + len(set(tr[GROUP_COL]) & set(te[GROUP_COL])) \
        + len(set(va[GROUP_COL]) & set(te[GROUP_COL]))
    lines.append(f"- GroupId overlap across splits: {overlap}  (0 = no duplicate-booking leakage between splits)\n")

    lines.append("## Missing values (train)")
    miss = tr.isna().sum()
    miss = miss[miss > 0]
    lines += [f"- {c}: {v:,} ({v / len(tr):.2%})" for c, v in miss.items()] or ["- none"]

    lines.append("\n## Data types (train)")
    lines.append(tr.dtypes.astype(str).value_counts().to_string())

    lines.append("\n## Unusual values (train)")
    lines.append(f"- ADR == 0: {(tr.ADR == 0).sum():,} rows ({(tr.ADR == 0).mean():.2%}), "
                 f"cancel rate {tr.loc[tr.ADR == 0, TARGET].mean():.3f}")
    lines.append(f"- TotalNights == 0: {(tr.TotalNights == 0).sum():,} rows")
    lines.append(f"- Babies >= 5: {(tr.Babies >= 5).sum()} rows; max Babies = {tr.Babies.max()}")
    lines.append(f"- LeadTime max = {tr.LeadTime.max()}; 99th pct = {tr.LeadTime.quantile(.99):.0f}")
    lines.append(f"- DaysInWaitingList > 0: {(tr.DaysInWaitingList > 0).mean():.2%}")
    lines.append(f"- DepositType value counts: {tr.DepositType.value_counts().to_dict()}")

    lines.append("\n## Cancellation rate by categorical feature (train)")
    for c in CAT_COLS:
        if c == "Agent":
            continue
        g = tr.groupby(c)[TARGET].agg(["mean", "size"]).sort_values("size", ascending=False)
        lines.append(f"\n**{c}**\n```\n{g.round(3).to_string()}\n```")

    num = tr.select_dtypes("number").drop(columns=[GROUP_COL])
    corr = num.corr()[TARGET].drop(TARGET).sort_values()
    lines.append("\n## Correlation with IsCanceled (train, Pearson)\n```\n" + corr.round(3).to_string() + "\n```")
    (REPORT_DIR).mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "eda_summary.md").write_text("\n".join(lines))

    # ---- figures ----
    fig, ax = plt.subplots(figsize=(4.5, 3.5))
    rates = [d[TARGET].mean() for d in (tr, va, te)]
    ax.bar(["train", "val", "test"], rates, color=["#4c72b0", "#55a868", "#c44e52"])
    ax.set_ylabel("cancellation rate"); ax.set_ylim(0, 0.6); ax.set_title("Target balance per split")
    for i, r in enumerate(rates):
        ax.text(i, r + 0.01, f"{r:.3f}", ha="center")
    fig.tight_layout(); fig.savefig(FIG_DIR / "eda_target_balance.png", dpi=150); plt.close(fig)

    cats = [c for c in CAT_COLS if c != "Agent"]
    fig, axes = plt.subplots(2, 4, figsize=(17, 7))
    for ax, c in zip(axes.ravel(), cats + ["Agent_top10"]):
        if c == "Agent_top10":
            top = tr.Agent.value_counts().head(10).index
            g = tr[tr.Agent.isin(top)].groupby("Agent")[TARGET].mean()
            g.index = g.index.astype(int).astype(str)
        else:
            g = tr.groupby(c)[TARGET].mean().sort_values()
        g.plot.barh(ax=ax, color="#4c72b0"); ax.set_title(c); ax.set_xlabel("cancel rate"); ax.set_xlim(0, 1)
    for ax in axes.ravel()[len(cats) + 1:]:
        ax.axis("off")
    fig.tight_layout(); fig.savefig(FIG_DIR / "eda_cancel_rate_by_category.png", dpi=130); plt.close(fig)

    key = ["LeadTime", "ADR", "TotalNights", "TotalOfSpecialRequests", "PreviousCancellations", "DaysInWaitingList"]
    fig, axes = plt.subplots(2, 3, figsize=(14, 7))
    for ax, c in zip(axes.ravel(), key):
        hi = tr[c].quantile(0.99)
        bins = np.linspace(0, max(hi, 1), 40)
        for t, col in ((0, "#55a868"), (1, "#c44e52")):
            ax.hist(tr.loc[tr[TARGET] == t, c].clip(upper=hi), bins=bins, alpha=0.55, color=col,
                    label="canceled" if t else "kept", density=True)
        ax.set_title(f"{c} (clipped at 99th pct)"); ax.legend()
    fig.tight_layout(); fig.savefig(FIG_DIR / "eda_numeric_distributions.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 7))
    corr.plot.barh(ax=ax, color=np.where(corr > 0, "#c44e52", "#4c72b0"))
    ax.set_title("Pearson correlation with IsCanceled (train)")
    fig.tight_layout(); fig.savefig(FIG_DIR / "eda_target_correlation.png", dpi=150); plt.close(fig)
    print("EDA done ->", REPORT_DIR)


if __name__ == "__main__":
    main()
