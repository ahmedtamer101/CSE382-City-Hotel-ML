"""Reusable preprocessing for the booking features.

All data-dependent steps (imputation values, scaling statistics, category lists) are
learned in .fit() and therefore must be fitted on TRAINING data only. The whole pipeline
(prep + model) is saved as one artifact so inference never retrains or re-fits anything.
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from hotel_ml.config import ALL_FEATURES, BIN_COLS, CAT_COLS, NUM_COLS, SKEW_COLS


def prepare_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Stateless cleaning: Agent id -> categorical string, missing agent -> 'None'."""
    # keep only model features, so extra columns (IsCanceled, GroupId, ...) are ignored at inference
    df = df[[c for c in ALL_FEATURES if c in df.columns]].copy()
    if "Agent" in df.columns:
        df["Agent"] = df["Agent"].apply(lambda v: "None" if pd.isna(v) else str(int(v)))
    return df


def build_preprocessor(drop_features=()) -> ColumnTransformer:
    """ColumnTransformer for the feature groups, optionally without some features."""
    drop = set(drop_features)
    keep = lambda cols: [c for c in cols if c not in drop]  # noqa: E731

    num = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    skew = Pipeline([
        ("log1p", FunctionTransformer(np.log1p, feature_names_out="one-to-one")),
        ("scale", StandardScaler()),
    ])
    cat = Pipeline([
        ("impute", SimpleImputer(strategy="constant", fill_value="Missing")),  # explicit "Missing" level
        # rare categories (<0.5% of train) are pooled into one 'infrequent' column;
        # categories never seen in training also fall into it at inference time
        ("onehot", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=0.005,
                                 sparse_output=False)),
    ])
    transformers = [
        ("num", num, keep(NUM_COLS)),
        ("skew", skew, keep(SKEW_COLS)),
        ("bin", "passthrough", keep(BIN_COLS)),
        ("cat", cat, keep(CAT_COLS)),
    ]
    transformers = [t for t in transformers if len(t[2]) > 0]
    return ColumnTransformer(transformers, remainder="drop", verbose_feature_names_out=True)


def build_pipeline(model, drop_features=()) -> Pipeline:
    """Full pipeline: raw booking DataFrame -> prepared -> encoded/scaled -> classifier."""
    return Pipeline([
        ("prepare", FunctionTransformer(prepare_frame, feature_names_out="one-to-one")),
        ("cols", build_preprocessor(drop_features)),
        ("clf", model),
    ])
