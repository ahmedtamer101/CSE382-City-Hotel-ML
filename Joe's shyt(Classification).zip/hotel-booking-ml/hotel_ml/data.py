"""Data loading helpers. The supervised test split is only loaded by explicit request."""
import pandas as pd

from hotel_ml.config import DATA_DIR, GROUP_COL, TARGET


def load_split(name: str) -> pd.DataFrame:
    """Load one of 'train', 'val', 'test' from data/splits/."""
    if name not in {"train", "val", "test"}:
        raise ValueError(f"unknown split: {name}")
    path = DATA_DIR / f"{name}.csv"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found - copy train/val/test.csv into data/splits/")
    return pd.read_csv(path)


def split_xy(df: pd.DataFrame):
    """Return (X, y, groups). GroupId is returned separately and never used as a feature."""
    y = df[TARGET].astype(int)
    groups = df[GROUP_COL] if GROUP_COL in df.columns else None
    X = df.drop(columns=[c for c in (TARGET, GROUP_COL) if c in df.columns])
    return X, y, groups
